from django.conf.urls import url
from django.urls import path, re_path

import routing.views as rv

urlpatterns = [
    path('simple_route/', rv.simple_route),
    re_path(r'^slug_route/[\w-]{1,16}/', rv.slug_route),
    re_path(r'^sum_route/(?P<a>[-]?\d+)/(?P<b>[-]?\d+)/', rv.sum_route),
    path('sum_get_method/', rv.sum_get_method),
    path('sum_post_method/', rv.sum_post_method),
]
