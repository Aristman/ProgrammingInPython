from django.http import HttpResponse


def simple_route(request):
    status = 200 if request.method == 'GET' else 405
    return HttpResponse('', status=status)


def slug_route(request):
    return HttpResponse()


def sum_route(request, a, b):
    return HttpResponse(str(int(a) + int(b)))


def sum_get_method(request):
    response = HttpResponse()
    response.status_code = 400
    params = request.GET
    if request.method == 'GET' and len(params) == 2:
        sum = 0
        try:
            for it in params:
                sum += int(params[it])
            response.status_code = 200
            response.content = str(sum)
        except Exception:
            return response
    return response


def sum_post_method(request):
    response = HttpResponse
    response.status_code = 400
    if request.method == 'POST':
        request.method = 'GET'
        response = sum_get_method(request)
    return response
